import boto3
import os

def handler(event, context):
    ecs_client = boto3.client('ecs')
    cluster_name = os.environ['CLUSTER_NAME']
    
    # List all services in the cluster
    services = ecs_client.list_services(cluster=cluster_name)
    
    # Scale down all services to 0
    for service_arn in services['serviceArns']:
        ecs_client.update_service(
            cluster=cluster_name,
            service=service_arn,
            desiredCount=0
        )
    
    return {
        'statusCode': 200,
        'body': f'Scaled down all services in {cluster_name}'
    }
